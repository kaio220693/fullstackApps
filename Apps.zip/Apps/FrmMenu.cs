﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Apps
{
    public partial class FrmMenu : Form
    {
        public FrmMenu()
        {
            InitializeComponent();
            FrmSplash splash = new FrmSplash();
            splash.Show();
            Application.DoEvents();
            Thread.Sleep(3500);
            splash.Close();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void PbxBuscaCep_Click(object sender, EventArgs e)
        {
            FrmBuscaCep buscaCep = new FrmBuscaCep();   
            buscaCep.Show();
        }

        private void PbxIR_Click(object sender, EventArgs e)
        {
            FrmIR buscaIR = new FrmIR();
            buscaIR.Show();
        }

        private void PbxIMC_Click(object sender, EventArgs e)
        {
            FrmIMC buscaIMC = new FrmIMC();
            buscaIMC.Show();
        }

        private void PbxConTemperatura_Click(object sender, EventArgs e)
        {
            FrmConversorTemperatura buscaConversorTemperatura = new FrmConversorTemperatura();
            buscaConversorTemperatura.Show();
        }

        private void PbxConsumo_Click(object sender, EventArgs e)
        {
            FrmMediaConsumo buscaMediaConsumo = new FrmMediaConsumo();  
            buscaMediaConsumo.Show();
        }
    }
}
