﻿namespace Apps
{
    partial class FrmMenu
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMenu));
            this.PbxBuscaCep = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.PbxConsumo = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.PbxIMC = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.PbxIR = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.PbxConTemperatura = new System.Windows.Forms.PictureBox();
            this.btnFechar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.PbxBuscaCep)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxConsumo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxIMC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxIR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxConTemperatura)).BeginInit();
            this.SuspendLayout();
            // 
            // PbxBuscaCep
            // 
            this.PbxBuscaCep.Image = global::Apps.Properties.Resources.cep;
            this.PbxBuscaCep.Location = new System.Drawing.Point(12, 12);
            this.PbxBuscaCep.Name = "PbxBuscaCep";
            this.PbxBuscaCep.Size = new System.Drawing.Size(135, 137);
            this.PbxBuscaCep.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PbxBuscaCep.TabIndex = 0;
            this.PbxBuscaCep.TabStop = false;
            this.PbxBuscaCep.Click += new System.EventHandler(this.PbxBuscaCep_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.SeaShell;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(36, 152);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Busca Cep";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label2.Location = new System.Drawing.Point(339, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Imposto de Renda";
            // 
            // PbxConsumo
            // 
            this.PbxConsumo.Image = global::Apps.Properties.Resources.gasalina;
            this.PbxConsumo.Location = new System.Drawing.Point(497, 197);
            this.PbxConsumo.Name = "PbxConsumo";
            this.PbxConsumo.Size = new System.Drawing.Size(135, 137);
            this.PbxConsumo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PbxConsumo.TabIndex = 2;
            this.PbxConsumo.TabStop = false;
            this.PbxConsumo.Click += new System.EventHandler(this.PbxConsumo_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label3.Location = new System.Drawing.Point(702, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "IMC";
            // 
            // PbxIMC
            // 
            this.PbxIMC.Image = global::Apps.Properties.Resources.imc;
            this.PbxIMC.Location = new System.Drawing.Point(653, 12);
            this.PbxIMC.Name = "PbxIMC";
            this.PbxIMC.Size = new System.Drawing.Size(135, 137);
            this.PbxIMC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PbxIMC.TabIndex = 4;
            this.PbxIMC.TabStop = false;
            this.PbxIMC.Click += new System.EventHandler(this.PbxIMC_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label4.Location = new System.Drawing.Point(136, 337);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(193, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Conversor de Temperatura";
            // 
            // PbxIR
            // 
            this.PbxIR.Image = global::Apps.Properties.Resources.leao;
            this.PbxIR.Location = new System.Drawing.Point(338, 12);
            this.PbxIR.Name = "PbxIR";
            this.PbxIR.Size = new System.Drawing.Size(135, 137);
            this.PbxIR.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PbxIR.TabIndex = 6;
            this.PbxIR.TabStop = false;
            this.PbxIR.Click += new System.EventHandler(this.PbxIR_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label5.Location = new System.Drawing.Point(494, 337);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Media de Consumo";
            // 
            // PbxConTemperatura
            // 
            this.PbxConTemperatura.Image = global::Apps.Properties.Resources.termo;
            this.PbxConTemperatura.Location = new System.Drawing.Point(162, 197);
            this.PbxConTemperatura.Name = "PbxConTemperatura";
            this.PbxConTemperatura.Size = new System.Drawing.Size(135, 137);
            this.PbxConTemperatura.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PbxConTemperatura.TabIndex = 8;
            this.PbxConTemperatura.TabStop = false;
            this.PbxConTemperatura.Click += new System.EventHandler(this.PbxConTemperatura_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.BackColor = System.Drawing.Color.White;
            this.btnFechar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnFechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFechar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFechar.ForeColor = System.Drawing.Color.Black;
            this.btnFechar.Location = new System.Drawing.Point(351, 232);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(96, 67);
            this.btnFechar.TabIndex = 10;
            this.btnFechar.Text = "FECHAR";
            this.btnFechar.UseVisualStyleBackColor = false;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // FrmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 367);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.PbxConTemperatura);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.PbxIR);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.PbxIMC);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.PbxConsumo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PbxBuscaCep);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Circo de Apps";
            ((System.ComponentModel.ISupportInitialize)(this.PbxBuscaCep)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxConsumo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxIMC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxIR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxConTemperatura)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox PbxBuscaCep;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox PbxConsumo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox PbxIMC;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox PbxIR;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox PbxConTemperatura;
        private System.Windows.Forms.Button btnFechar;
    }
}

